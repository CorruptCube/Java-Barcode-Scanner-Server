package wetsch.wirelessbarcodescannerserver;



import wetsch.wirelessbarcodescannerserver.gui.MainPanel;

public class RunStandAloneInterface{
	public static void main(String[] srgs){
		new MainPanel();
	}

}
