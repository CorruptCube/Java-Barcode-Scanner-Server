package wetsch.jbcsserver;



import wetsch.jbcsserver.gui.MainPanel;

public class RunStandAloneInterface{
	public static void main(String[] srgs){
		new MainPanel();
	}

}
